const express = require('express');
const router = express.Router();

// No implementation provided in the original Next.js API

module.exports = router; 